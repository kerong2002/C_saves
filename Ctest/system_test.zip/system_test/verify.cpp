#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(){
	FILE *stream1=fopen("answer_output.txt", "r");
	FILE *stream2=fopen("classmates_output.txt", "r");
	char answer[999];
	char classmates[999];	
	while((fscanf(stream1, "%[^\n]", answer)!= EOF)and(fscanf(stream2, "%[^\n]", classmates)!= EOF))
	{
	    fgetc(stream1);
		fgetc(stream2); 
		if(!strcmp(answer , classmates)){
		    printf("pass\n");
		}
		if(strcmp(answer , classmates)){
		    printf("%s This output is not currect. Currect answer is %s\n",classmates,answer);
		}
//	    printf(">%s \n",answer);
//	    printf(">%s \n",classmates);
		
	}

	fclose(stream1);
	fclose(stream2);
	return 0;
}

